import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class CustomBottomBar extends StatefulWidget {
  CustomBottomBar({this.onChanged});

  Function(BottomBarEnum)? onChanged;

  @override
  CustomBottomBarState createState() => CustomBottomBarState();
}

class CustomBottomBarState extends State<CustomBottomBar> {
  int selectedIndex = 0;

  List<BottomMenuModel> bottomMenuList = [
    BottomMenuModel(
      icon: ImageConstant.imgEllipse133,
      activeIcon: ImageConstant.imgEllipse133,
      type: BottomBarEnum.Ellipse133,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgEllipse132,
      activeIcon: ImageConstant.imgEllipse132,
      type: BottomBarEnum.Ellipse132,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgEllipse131,
      activeIcon: ImageConstant.imgEllipse131,
      type: BottomBarEnum.Ellipse131,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgEllipse130,
      activeIcon: ImageConstant.imgEllipse130,
      type: BottomBarEnum.Ellipse130,
    )
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 91.v,
      decoration: BoxDecoration(
        color: appTheme.teal900,
        borderRadius: BorderRadius.circular(
          15.h,
        ),
      ),
      child: BottomNavigationBar(
        backgroundColor: Colors.transparent,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        selectedFontSize: 0,
        elevation: 0,
        currentIndex: selectedIndex,
        type: BottomNavigationBarType.fixed,
        items: List.generate(bottomMenuList.length, (index) {
          return BottomNavigationBarItem(
            icon: CustomImageView(
              imagePath: ImageConstant.imgEllipse132,
              height: 58.v,
              width: 61.h,
              radius: BorderRadius.circular(
                30.h,
              ),
            ),
            activeIcon: CustomImageView(
              imagePath: ImageConstant.imgEllipse133,
              height: 58.v,
              width: 61.h,
              radius: BorderRadius.circular(
                30.h,
              ),
            ),
            label: '',
          );
        }),
        onTap: (index) {
          selectedIndex = index;
          widget.onChanged?.call(bottomMenuList[index].type);
          setState(() {});
        },
      ),
    );
  }
}

enum BottomBarEnum {
  Ellipse133,
  Ellipse132,
  Ellipse131,
  Ellipse130,
}

class BottomMenuModel {
  BottomMenuModel({
    required this.icon,
    required this.activeIcon,
    required this.type,
  });

  String icon;

  String activeIcon;

  BottomBarEnum type;
}

class DefaultWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Color(0xffffffff),
      padding: EdgeInsets.all(10),
      child: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Please replace the respective Widget here',
              style: TextStyle(
                fontSize: 18,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
