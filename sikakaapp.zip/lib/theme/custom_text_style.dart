import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/utils/size_utils.dart';
import 'package:ahmed_s_application6/theme/theme_helper.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Body text style
  static get bodyLargeGray600 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.gray600,
        fontSize: 17.fSize,
      );
  static get bodyLargeGray60001 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.gray60001,
        fontSize: 17.fSize,
      );
  static get bodyLargeInterErrorContainer =>
      theme.textTheme.bodyLarge!.inter.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
        fontWeight: FontWeight.w200,
      );
  static get bodyLargeInterPrimaryContainer =>
      theme.textTheme.bodyLarge!.inter.copyWith(
        color: theme.colorScheme.primaryContainer,
        fontWeight: FontWeight.w200,
      );
  static get bodyLargeInterWhiteA700 =>
      theme.textTheme.bodyLarge!.inter.copyWith(
        color: appTheme.whiteA700,
        fontWeight: FontWeight.w200,
      );
  static get bodyLargeRedA200 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.redA200,
      );
  static get bodyLargeTeal900 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.teal900,
        fontSize: 17.fSize,
      );
  static get bodyMedium14 => theme.textTheme.bodyMedium!.copyWith(
        fontSize: 14.fSize,
      );
  static get bodyMediumPoppinsErrorContainer =>
      theme.textTheme.bodyMedium!.poppins.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(0.71),
        fontSize: 15.fSize,
      );
  static get bodyMediumPoppinsErrorContainer15 =>
      theme.textTheme.bodyMedium!.poppins.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(0.29),
        fontSize: 15.fSize,
      );
  static get bodyMediumPoppinsErrorContainer15_1 =>
      theme.textTheme.bodyMedium!.poppins.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(0.31),
        fontSize: 15.fSize,
      );
  static get bodyMediumPoppinsErrorContainer15_2 =>
      theme.textTheme.bodyMedium!.poppins.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(0.55),
        fontSize: 15.fSize,
      );
  static get bodySmallInterWhiteA700 =>
      theme.textTheme.bodySmall!.inter.copyWith(
        color: appTheme.whiteA700,
        fontSize: 12.fSize,
      );
  // Headline text style
  static get headlineLargeCyan900 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.cyan900,
        fontSize: 32.fSize,
        fontWeight: FontWeight.w900,
      );
  static get headlineLargePoppins =>
      theme.textTheme.headlineLarge!.poppins.copyWith(
        fontSize: 32.fSize,
        fontWeight: FontWeight.w600,
      );
  static get headlineMediumRegular => theme.textTheme.headlineMedium!.copyWith(
        fontWeight: FontWeight.w400,
      );
  static get headlineSmallErrorContainer =>
      theme.textTheme.headlineSmall!.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(0.71),
        fontWeight: FontWeight.w400,
      );
  static get headlineSmallInter => theme.textTheme.headlineSmall!.inter;
  // Label text style
  static get labelMedium10 => theme.textTheme.labelMedium!.copyWith(
        fontSize: 10.fSize,
      );
  static get labelMediumWhiteA700 => theme.textTheme.labelMedium!.copyWith(
        color: appTheme.whiteA700,
        fontWeight: FontWeight.w600,
      );
  // Poppins text style
  static get poppinsGray800b7 => TextStyle(
        color: appTheme.gray800B7,
        fontSize: 7.fSize,
        fontWeight: FontWeight.w400,
      ).poppins;
  static get poppinsGray800b7Regular => TextStyle(
        color: appTheme.gray800B7.withOpacity(0.75),
        fontSize: 7.fSize,
        fontWeight: FontWeight.w400,
      ).poppins;
  // Title text style
  static get titleLargeInter => theme.textTheme.titleLarge!.inter.copyWith(
        fontWeight: FontWeight.w200,
      );
  static get titleLargeInterff000000 =>
      theme.textTheme.titleLarge!.inter.copyWith(
        color: Color(0XFF000000),
        fontWeight: FontWeight.w200,
      );
  static get titleLargeInterff1a5c78 =>
      theme.textTheme.titleLarge!.inter.copyWith(
        color: Color(0XFF1A5C78),
        fontWeight: FontWeight.w200,
      );
  static get titleLargeInterffff5757 =>
      theme.textTheme.titleLarge!.inter.copyWith(
        color: Color(0XFFFF5757),
        fontWeight: FontWeight.w200,
      );
  static get titleMediumGray500 => theme.textTheme.titleMedium!.copyWith(
        color: appTheme.gray500,
      );
  static get titleMediumGray60002 => theme.textTheme.titleMedium!.copyWith(
        color: appTheme.gray60002,
      );
  static get titleMediumPoppinsErrorContainer =>
      theme.textTheme.titleMedium!.poppins.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
        fontSize: 17.fSize,
        fontWeight: FontWeight.w700,
      );
  static get titleMediumPoppinsErrorContainerSemiBold =>
      theme.textTheme.titleMedium!.poppins.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
        fontWeight: FontWeight.w600,
      );
  static get titleMediumRalewayTeal900 =>
      theme.textTheme.titleMedium!.raleway.copyWith(
        color: appTheme.teal900,
        fontSize: 17.fSize,
        fontWeight: FontWeight.w700,
      );
  static get titleSmallInterErrorContainer =>
      theme.textTheme.titleSmall!.inter.copyWith(
        color: theme.colorScheme.errorContainer.withOpacity(1),
        fontWeight: FontWeight.w500,
      );
}

extension on TextStyle {
  TextStyle get poppins {
    return copyWith(
      fontFamily: 'Poppins',
    );
  }

  TextStyle get inter {
    return copyWith(
      fontFamily: 'Inter',
    );
  }

  TextStyle get raleway {
    return copyWith(
      fontFamily: 'Raleway',
    );
  }
}
