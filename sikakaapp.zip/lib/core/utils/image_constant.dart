class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // info images
  static String imgImg94902 = '$imagePath/img_img_9490_2.png';

  // logout images
  static String imgImg9490264x98 = '$imagePath/img_img_9490_2_64x98.png';

  static String imgVector = '$imagePath/img_vector.svg';

  static String imgIconPerson = '$imagePath/img_icon_person.svg';

  static String imgGroup = '$imagePath/img_group.svg';

  // booklist images
  static String imgArrowDown = '$imagePath/img_arrow_down.svg';

  // bookdetails images
  static String imgImg9490250x105 = '$imagePath/img_img_9490_2_50x105.png';

  static String imgVector3 = '$imagePath/img_vector_3.png';

  static String imgDownload1222x159 = '$imagePath/img_download_1_222x159.png';

  static String imgSort = '$imagePath/img_sort.png';

  static String imgCocoBoldSaved = '$imagePath/img_coco_bold_saved.svg';

  // favbooks images
  static String imgImg9490264x99 = '$imagePath/img_img_9490_2_64x99.png';

  static String imgFavorite = '$imagePath/img_favorite.svg';

  // mainuser images
  static String imgImg9490264x93 = '$imagePath/img_img_9490_2_64x93.png';

  static String imgDownload4 = '$imagePath/img_download_4.png';

  static String imgRectangle17 = '$imagePath/img_rectangle_17.png';

  static String imgDownload3 = '$imagePath/img_download_3.png';

  static String imgDownload2 = '$imagePath/img_download_2.png';

  static String imgCocoBoldHome = '$imagePath/img_coco_bold_home.svg';

  static String imgGroup143 = '$imagePath/img_group_143.png';

  static String imgCocoBoldSetting = '$imagePath/img_coco_bold_setting.svg';

  static String imgCocoBoldSavedWhiteA700 =
      '$imagePath/img_coco_bold_saved_white_a700.svg';

  // intro images
  static String imgPolygon17 = '$imagePath/img_polygon_17.png';

  static String imgManWomanStudy = '$imagePath/img_man_woman_study.png';

  static String imgArrowRight = '$imagePath/img_arrow_right.svg';

  static String imgPolygon9 = '$imagePath/img_polygon_9.png';

  static String imgEllipse8 = '$imagePath/img_ellipse_8.png';

  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgUser = '$imagePath/img_user.svg';

  static String imgUserOrange200 = '$imagePath/img_user_orange_200.png';

  // chooseaccount images
  static String imgIphone1314 = '$imagePath/img_iphone_13_14.png';

  // splash images
  static String imgImg94891 = '$imagePath/img_img_9489_1.png';

  // librariesmap images
  static String imgImg9490242x100 = '$imagePath/img_img_9490_2_42x100.png';

  static String imgShape = '$imagePath/img_shape.svg';

  static String imgMaskGroup = '$imagePath/img_mask_group.png';

  static String imgDownload23 = '$imagePath/img_download_23.png';

  static String imgDownload27 = '$imagePath/img_download_27.png';

  // bookrequired images
  static String imgImg9490255x109 = '$imagePath/img_img_9490_2_55x109.png';

  static String imgDownload14 = '$imagePath/img_download_14.png';

  static String imgShopping3 = '$imagePath/img_shopping_3.png';

  static String imgImages3 = '$imagePath/img_images_3.png';

  // booksavailable images
  static String imgImg9490260x114 = '$imagePath/img_img_9490_2_60x114.png';

  static String imgDownload9 = '$imagePath/img_download_9.png';

  static String imgDownload12 = '$imagePath/img_download_12.png';

  static String imgImages2 = '$imagePath/img_images_2.png';

  // librarymain images
  static String imgImg9490274x111 = '$imagePath/img_img_9490_2_74x111.png';

  static String imgDownload9131x85 = '$imagePath/img_download_9_131x85.png';

  static String imgShopping3131x97 = '$imagePath/img_shopping_3_131x97.png';

  static String imgEllipse133 = '$imagePath/img_ellipse_133.png';

  static String imgEllipse132 = '$imagePath/img_ellipse_132.png';

  static String imgEllipse131 = '$imagePath/img_ellipse_131.png';

  static String imgEllipse130 = '$imagePath/img_ellipse_130.png';

  // libraryregister images
  static String imgDownload225x25 = '$imagePath/img_download_2_25x25.png';

  // Common images
  static String imgCocoBoldSearch = '$imagePath/img_coco_bold_search.svg';

  static String imgDownload1 = '$imagePath/img_download_1.png';

  static String imgImages1 = '$imagePath/img_images_1.png';

  static String img21301 = '$imagePath/img_2_130_1.png';

  static String imgDownload13 = '$imagePath/img_download_13.png';

  static String imgDownload10 = '$imagePath/img_download_10.png';

  static String imgArrowLeftRedA200 = '$imagePath/img_arrow_left_red_a200.svg';

  static String imgLock = '$imagePath/img_lock.svg';

  static String imgCheckmark = '$imagePath/img_checkmark.svg';

  static String imgDownload133x37 = '$imagePath/img_download_1_33x37.png';

  static String imgEye = '$imagePath/img_eye.svg';

  static String imgLocation = '$imagePath/img_location.svg';

  static String imgArrowLeftWhiteA700 =
      '$imagePath/img_arrow_left_white_a700.svg';

  static String imgImg94901 = '$imagePath/img_img_9490_1.png';

  static String imgHamburgerMenu = '$imagePath/img_hamburger_menu.svg';

  static String imgArrowLeftTeal900 = '$imagePath/img_arrow_left_teal_900.svg';

  static String imgDownload6 = '$imagePath/img_download_6.png';

  static String imgDownload7 = '$imagePath/img_download_7.png';

  static String imgDownload5 = '$imagePath/img_download_5.png';

  static String imgShopping1 = '$imagePath/img_shopping_1.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
