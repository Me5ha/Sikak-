import 'package:flutter/material.dart';
import '../presentation/info_screen/info_screen.dart';
import '../presentation/logout_screen/logout_screen.dart';
import '../presentation/booklist_screen/booklist_screen.dart';
import '../presentation/bookdetails_screen/bookdetails_screen.dart';
import '../presentation/favbooks_screen/favbooks_screen.dart';
import '../presentation/mainuser_screen/mainuser_screen.dart';
import '../presentation/intro_screen/intro_screen.dart';
import '../presentation/userregister_screen/userregister_screen.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/chooseaccount_screen/chooseaccount_screen.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/librariesmap_screen/librariesmap_screen.dart';
import '../presentation/bookrequired_screen/bookrequired_screen.dart';
import '../presentation/booksavailable_screen/booksavailable_screen.dart';
import '../presentation/librarymain_screen/librarymain_screen.dart';
import '../presentation/libraryregister_screen/libraryregister_screen.dart';
import '../presentation/librarylogin_screen/librarylogin_screen.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String infoScreen = '/info_screen';

  static const String logoutScreen = '/logout_screen';

  static const String booklistScreen = '/booklist_screen';

  static const String bookdetailsScreen = '/bookdetails_screen';

  static const String favbooksScreen = '/favbooks_screen';

  static const String mainuserScreen = '/mainuser_screen';

  static const String introScreen = '/intro_screen';

  static const String userregisterScreen = '/userregister_screen';

  static const String loginScreen = '/login_screen';

  static const String chooseaccountScreen = '/chooseaccount_screen';

  static const String splashScreen = '/splash_screen';

  static const String librariesmapScreen = '/librariesmap_screen';

  static const String bookrequiredScreen = '/bookrequired_screen';

  static const String booksavailableScreen = '/booksavailable_screen';

  static const String librarymainScreen = '/librarymain_screen';

  static const String libraryregisterScreen = '/libraryregister_screen';

  static const String libraryloginScreen = '/librarylogin_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    infoScreen: (context) => InfoScreen(),
    logoutScreen: (context) => LogoutScreen(),
    booklistScreen: (context) => BooklistScreen(),
    bookdetailsScreen: (context) => BookdetailsScreen(),
    favbooksScreen: (context) => FavbooksScreen(),
    mainuserScreen: (context) => MainuserScreen(),
    introScreen: (context) => IntroScreen(),
    userregisterScreen: (context) => UserregisterScreen(),
    loginScreen: (context) => LoginScreen(),
    chooseaccountScreen: (context) => ChooseaccountScreen(),
    splashScreen: (context) => SplashScreen(),
    librariesmapScreen: (context) => LibrariesmapScreen(),
    bookrequiredScreen: (context) => BookrequiredScreen(),
    booksavailableScreen: (context) => BooksavailableScreen(),
    librarymainScreen: (context) => LibrarymainScreen(),
    libraryregisterScreen: (context) => LibraryregisterScreen(),
    libraryloginScreen: (context) => LibraryloginScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
