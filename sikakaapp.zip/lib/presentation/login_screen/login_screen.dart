import 'package:ahmed_s_application6/widgets/custom_text_form_field.dart';
import 'package:ahmed_s_application6/widgets/custom_switch.dart';
import 'package:ahmed_s_application6/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

// ignore_for_file: must_be_immutable
class LoginScreen extends StatefulWidget {
  LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController checkmarkController = TextEditingController();

  TextEditingController eyeController = TextEditingController();

  bool isSelectedSwitch = false;

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Form(
                        key: _formKey,
                        child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.only(
                                left: 25.h, top: 73.v, right: 25.h),
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  CustomImageView(
                                      imagePath: ImageConstant.imgImg94901,
                                      height: 123.v,
                                      width: 210.h,
                                      alignment: Alignment.center),
                                  SizedBox(height: 65.v),
                                  Padding(
                                      padding: EdgeInsets.only(right: 10.h),
                                      child: Center(
                                        child: Text("تسجيل الدخول",
                                            style: CustomTextStyles
                                                .headlineMediumRegular),
                                      )),
                                  SizedBox(height: 20.v),
                                  Padding(
                                      padding: EdgeInsets.only(left: 7.h),
                                      child: CustomTextFormField(
                                          controller: checkmarkController,
                                          hintText: "البريد الالكتروني...",
                                          hintStyle:
                                              theme.textTheme.titleMedium!,
                                          suffix: Container(
                                              margin: EdgeInsets.fromLTRB(
                                                  16.h, 19.v, 26.h, 19.v),
                                              child: CustomImageView(
                                                  imagePath: ImageConstant
                                                      .imgCheckmark,
                                                  height: 24.v,
                                                  width: 23.h)),
                                          suffixConstraints:
                                              BoxConstraints(maxHeight: 63.v),
                                          borderDecoration:
                                              TextFormFieldStyleHelper
                                                  .outlineGrayTL122)),
                                  SizedBox(height: 21.v),
                                  Padding(
                                      padding: EdgeInsets.only(
                                          left: 7.h, right: 1.h),
                                      child: CustomTextFormField(
                                          controller: eyeController,
                                          hintText: "كلمة المرور...",
                                          hintStyle:
                                              theme.textTheme.titleMedium!,
                                          textInputAction: TextInputAction.done,
                                          textInputType:
                                              TextInputType.visiblePassword,
                                          prefix: Container(
                                              margin: EdgeInsets.fromLTRB(
                                                  13.h, 18.v, 30.h, 18.v),
                                              child: CustomImageView(
                                                  imagePath:
                                                      ImageConstant.imgEye,
                                                  height: 27.v,
                                                  width: 25.h)),
                                          prefixConstraints:
                                              BoxConstraints(maxHeight: 65.v),
                                          suffix: Container(
                                              margin: EdgeInsets.fromLTRB(
                                                  14.h, 17.v, 24.h, 19.v),
                                              child: CustomImageView(
                                                  imagePath:
                                                      ImageConstant.imgLocation,
                                                  height: 29.v,
                                                  width: 30.h)),
                                          suffixConstraints:
                                              BoxConstraints(maxHeight: 65.v),
                                          obscureText: true,
                                          contentPadding: EdgeInsets.symmetric(
                                              vertical: 22.v),
                                          borderDecoration:
                                              TextFormFieldStyleHelper
                                                  .outlineGrayTL121)),
                                  SizedBox(height: 30.v),
                                  Padding(
                                      padding: EdgeInsets.only(
                                          left: 29.h, right: 10.h),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Text("نسيت كلمة المرور؟ ",
                                                style: CustomTextStyles
                                                    .titleSmallInterErrorContainer),
                                            Spacer(),
                                            Padding(
                                                padding:
                                                    EdgeInsets.only(top: 2.v),
                                                child: Text("تذكرني",
                                                    style: CustomTextStyles
                                                        .titleSmallInterErrorContainer)),
                                            CustomSwitch(
                                                margin:
                                                    EdgeInsets.only(left: 7.h),
                                                value: isSelectedSwitch,
                                                onChange: (value) {
                                                  isSelectedSwitch = value;
                                                })
                                          ])),
                                  SizedBox(height: 69.v),
                                  Align(
                                      alignment: Alignment.center,
                                      child: SizedBox(
                                          height: 58.v,
                                          width: 271.h,
                                          child: Stack(
                                              alignment: Alignment.bottomCenter,
                                              children: [
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: GestureDetector(
                                                        onTap: () {
                                                          onTapArrowLeft(
                                                              context);
                                                        },
                                                        child: Container(
                                                            height: 58.v,
                                                            width: 271.h,
                                                            padding:
                                                                EdgeInsets.all(
                                                                    14.h),
                                                            decoration: AppDecoration
                                                                .outlinePrimary
                                                                .copyWith(
                                                                    borderRadius:
                                                                        BorderRadiusStyle
                                                                            .circleBorder15),
                                                            child: CustomIconButton(
                                                                height: 30
                                                                    .adaptSize,
                                                                width: 30
                                                                    .adaptSize,
                                                                padding:
                                                                    EdgeInsets.all(
                                                                        8.h),
                                                                decoration:
                                                                    IconButtonStyleHelper
                                                                        .fillRed,
                                                                alignment: Alignment
                                                                    .centerRight,
                                                                child: CustomImageView(imagePath: ImageConstant.imgArrowLeftWhiteA700))))),
                                                Align(
                                                    alignment:
                                                        Alignment.bottomCenter,
                                                    child: Padding(
                                                        padding:
                                                            EdgeInsets.only(
                                                                bottom: 16.v),
                                                        child: Text(
                                                            "سجل دخول"
                                                                .toUpperCase(),
                                                            style: CustomTextStyles
                                                                .bodyLargeInterPrimaryContainer)))
                                              ]))),
                                  SizedBox(height: 1.v),
                                  GestureDetector(
                                      onTap: () {
                                        onTapTxttf(context);
                                      },
                                      child: Padding(
                                          padding: EdgeInsets.only(right: 39.h),
                                          child: RichText(
                                              text: TextSpan(children: [
                                                TextSpan(
                                                    text: "ليس لديك حساب؟ ",
                                                    style: CustomTextStyles
                                                        .titleLargeInterff000000),
                                                TextSpan(
                                                    text: "سجل الان",
                                                    style: CustomTextStyles
                                                        .titleLargeInterffff5757)
                                              ]),
                                              textAlign: TextAlign.left))),
                                  SizedBox(height: 5.v)
                                ])))))));
  }

  /// Navigates to the introScreen when the action is triggered.
  onTapArrowLeft(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.introScreen);
  }

  /// Navigates to the userregisterScreen when the action is triggered.
  onTapTxttf(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.userregisterScreen);
  }
}
