import 'package:ahmed_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_trailing_image.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class InfoScreen extends StatelessWidget {
  const InfoScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 9.h,
            vertical: 24.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.only(right: 8.h),
                child: Text(
                  "الأسم",
                  style: CustomTextStyles.headlineSmallErrorContainer,
                ),
              ),
              SizedBox(height: 1.v),
              Padding(
                padding: EdgeInsets.only(right: 7.h),
                child: Text(
                  "أمجد",
                  style: CustomTextStyles.bodyMediumPoppinsErrorContainer15_2,
                ),
              ),
              SizedBox(height: 40.v),
              Padding(
                padding: EdgeInsets.only(right: 4.h),
                child: Text(
                  "رقم الهاتف",
                  style: CustomTextStyles.headlineSmallErrorContainer,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(right: 5.h),
                child: Text(
                  "0553628231",
                  style: CustomTextStyles.bodyMediumPoppinsErrorContainer15_2,
                ),
              ),
              SizedBox(height: 36.v),
              Text(
                "اسم المستخدم",
                style: CustomTextStyles.headlineSmallErrorContainer,
              ),
              Padding(
                padding: EdgeInsets.only(right: 7.h),
                child: Text(
                  "amjd",
                  style: CustomTextStyles.bodyMediumPoppinsErrorContainer15_2,
                ),
              ),
              SizedBox(height: 46.v),
              Padding(
                padding: EdgeInsets.only(right: 4.h),
                child: Text(
                  "البريد الألكتروني",
                  style: CustomTextStyles.headlineSmallErrorContainer,
                ),
              ),
              SizedBox(height: 2.v),
              Padding(
                padding: EdgeInsets.only(right: 4.h),
                child: Text(
                  "amjd726@gmail.com",
                  style: CustomTextStyles.bodyMediumPoppinsErrorContainer15_2,
                ),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgImg94902,
        ),
      ],
    );
  }
}
