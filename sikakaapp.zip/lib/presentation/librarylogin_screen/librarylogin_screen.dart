import 'package:ahmed_s_application6/presentation/librarymain_screen/home_library.dart';
import 'package:ahmed_s_application6/widgets/custom_text_form_field.dart';
import 'package:ahmed_s_application6/widgets/custom_switch.dart';
import 'package:ahmed_s_application6/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

// ignore_for_file: must_be_immutable
class LibraryloginScreen extends StatelessWidget {
  LibraryloginScreen({Key? key}) : super(key: key);

  TextEditingController checkmarkController = TextEditingController();

  TextEditingController eyeController = TextEditingController();

  bool isSelectedSwitch = false;

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: Column(children: [
                      SizedBox(height: 73.v),
                      Expanded(
                          child: SingleChildScrollView(
                              child: Container(
                                  margin: EdgeInsets.only(bottom: 181.v),
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 19.h),
                                  child: Column(children: [
                                    CustomImageView(
                                        imagePath: ImageConstant.imgImg94901,
                                        height: 123.v,
                                        width: 210.h),
                                    SizedBox(height: 65.v),
                                    Align(
                                        alignment: Alignment.centerRight,
                                        child: Center(
                                          child: Text("تسجيل الدخول",
                                              style: theme
                                                  .textTheme.headlineMedium),
                                        )),
                                    SizedBox(height: 20.v),
                                    Padding(
                                        padding: EdgeInsets.only(
                                            left: 12.h, right: 5.h),
                                        child: CustomTextFormField(
                                            controller: checkmarkController,
                                            hintText: "البريد الالكتروني...",
                                            hintStyle:
                                                theme.textTheme.titleMedium!,
                                            suffix: Container(
                                                margin: EdgeInsets.fromLTRB(
                                                    16.h, 19.v, 26.h, 19.v),
                                                child: CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgCheckmark,
                                                    height: 24.v,
                                                    width: 23.h)),
                                            suffixConstraints:
                                                BoxConstraints(maxHeight: 63.v),
                                            borderDecoration:
                                                TextFormFieldStyleHelper
                                                    .outlineGrayTL122)),
                                    SizedBox(height: 21.v),
                                    Padding(
                                        padding: EdgeInsets.only(
                                            left: 12.h, right: 6.h),
                                        child: CustomTextFormField(
                                            controller: eyeController,
                                            hintText: "كلمة المرور...",
                                            hintStyle:
                                                theme.textTheme.titleMedium!,
                                            textInputAction:
                                                TextInputAction.done,
                                            textInputType:
                                                TextInputType.visiblePassword,
                                            prefix: Container(
                                                margin: EdgeInsets.fromLTRB(
                                                    13.h, 18.v, 30.h, 18.v),
                                                child: CustomImageView(
                                                    imagePath:
                                                        ImageConstant.imgEye,
                                                    height: 27.v,
                                                    width: 25.h)),
                                            prefixConstraints:
                                                BoxConstraints(maxHeight: 65.v),
                                            suffix: Container(
                                                margin: EdgeInsets.fromLTRB(
                                                    14.h, 17.v, 24.h, 19.v),
                                                child: CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgLocation,
                                                    height: 29.v,
                                                    width: 30.h)),
                                            suffixConstraints:
                                                BoxConstraints(maxHeight: 65.v),
                                            obscureText: true,
                                            contentPadding:
                                                EdgeInsets.symmetric(
                                                    vertical: 22.v),
                                            borderDecoration:
                                                TextFormFieldStyleHelper
                                                    .outlineGrayTL121)),
                                    SizedBox(height: 30.v),
                                    Padding(
                                        padding: EdgeInsets.only(
                                            left: 34.h, right: 17.h),
                                        child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text("نسيت كلمة المرور؟ ",
                                                  style: CustomTextStyles
                                                      .titleSmallInterErrorContainer),
                                              Spacer(),
                                              Padding(
                                                  padding:
                                                      EdgeInsets.only(top: 2.v),
                                                  child: Text("تذكرني",
                                                      style: CustomTextStyles
                                                          .titleSmallInterErrorContainer)),
                                              CustomSwitch(
                                                  margin: EdgeInsets.only(
                                                      left: 7.h),
                                                  value: isSelectedSwitch,
                                                  onChange: (value) {
                                                    isSelectedSwitch = value;
                                                  })
                                            ])),
                                    SizedBox(height: 69.v),
                                    CustomElevatedButton(
                                        height: 58.v,
                                        text: "سجل دخول".toUpperCase(),
                                        margin: EdgeInsets.only(
                                            left: 47.h, right: 32.h),
                                        buttonStyle:
                                            CustomButtonStyles.outlinePrimary,
                                        buttonTextStyle: CustomTextStyles
                                            .bodyLargeInterWhiteA700,
                                        onPressed: () {
                                          onTaptf(context);
                                        }),
                                    SizedBox(height: 1.v),
                                    Align(
                                        alignment: Alignment.centerRight,
                                        child: GestureDetector(
                                            onTap: () {
                                              onTapTxttf(context);
                                            },
                                            child: Padding(
                                                padding: EdgeInsets.only(
                                                    right: 45.h),
                                                child: RichText(
                                                    text: TextSpan(children: [
                                                      TextSpan(
                                                          text:
                                                              "ليس لديك حساب؟ ",
                                                          style: CustomTextStyles
                                                              .titleLargeInterff000000),
                                                      TextSpan(
                                                          text: "سجل الان",
                                                          style: CustomTextStyles
                                                              .titleLargeInterff1a5c78)
                                                    ]),
                                                    textAlign:
                                                        TextAlign.left))))
                                  ]))))
                    ])))));
  }

  /// Navigates to the librarymainScreen when the action is triggered.
  onTaptf(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => HomeLibrary()));
  }

  /// Navigates to the libraryregisterScreen when the action is triggered.
  onTapTxttf(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.libraryregisterScreen);
  }
}
