import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class ChooseaccountScreen extends StatelessWidget {
  const ChooseaccountScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            body: Container(
                width: SizeUtils.width,
                height: SizeUtils.height,
                decoration: BoxDecoration(
                    color: appTheme.whiteA700,
                    border: Border.all(
                        color: theme.colorScheme.errorContainer.withOpacity(1),
                        width: 1.h),
                    boxShadow: [
                      BoxShadow(
                          color: theme.colorScheme.errorContainer
                              .withOpacity(0.25),
                          spreadRadius: 2.h,
                          blurRadius: 2.h,
                          offset: Offset(0, 4))
                    ],
                    image: DecorationImage(
                        image: AssetImage(ImageConstant.imgIphone1314),
                        fit: BoxFit.cover)),
                child: SizedBox(
                    width: double.maxFinite,
                    child: Container(
                        width: double.maxFinite,
                        padding: EdgeInsets.symmetric(
                            horizontal: 14.h, vertical: 133.v),
                        decoration:
                            AppDecoration.gradientOnPrimaryContainerToOnPrimary,
                        child: Column(children: [
                          _buildWidget(context),
                          SizedBox(height: 88.v),
                          _buildView(context),
                          SizedBox(height: 80.v)
                        ]))))));
  }

  /// Section Widget
  Widget _buildWidget(BuildContext context) {
    return Align(
        alignment: Alignment.centerRight,
        child: SizedBox(
            height: 189.v,
            width: 343.h,
            child: Stack(alignment: Alignment.centerRight, children: [
              Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                      margin: EdgeInsets.only(right: 19.h),
                      decoration: AppDecoration.fillWhiteA.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder31),
                      child: GestureDetector(
                          onTap: () {
                            onTapOne(context);
                          },
                          child: Container(
                              margin: EdgeInsets.only(right: 158.h),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 48.h, vertical: 50.v),
                              decoration: AppDecoration.fillRedA.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.customBorderTL20),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text("افراد",
                                        style: theme.textTheme.displayMedium)
                                  ]))))),
              CustomImageView(
                  imagePath: ImageConstant.imgImg94901,
                  height: 123.v,
                  width: 181.h,
                  alignment: Alignment.centerRight)
            ])));
  }

  /// Section Widget
  Widget _buildView(BuildContext context) {
    return SizedBox(
        height: 189.v,
        width: 343.h,
        child: Stack(alignment: Alignment.centerLeft, children: [
          Align(
              alignment: Alignment.centerLeft,
              child: Container(
                  margin: EdgeInsets.only(right: 19.h),
                  decoration: BoxDecoration(
                      color: appTheme.whiteA700,
                      borderRadius: BorderRadius.circular(31.h)))),
          Align(
              alignment: Alignment.centerLeft,
              child: GestureDetector(
                  onTap: () {
                    onTapTwo(context);
                  },
                  child: Container(
                      margin: EdgeInsets.only(right: 158.h),
                      padding: EdgeInsets.symmetric(
                          horizontal: 35.h, vertical: 50.v),
                      decoration: AppDecoration.fillTeal.copyWith(
                          borderRadius: BorderRadiusStyle.customBorderTL20),
                      child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text("مكتبات", style: theme.textTheme.displayMedium)
                          ])))),
          CustomImageView(
              imagePath: ImageConstant.imgImg94901,
              height: 123.v,
              width: 181.h,
              alignment: Alignment.centerRight)
        ]));
  }

  /// Navigates to the loginScreen when the action is triggered.
  onTapOne(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginScreen);
  }

  /// Navigates to the libraryloginScreen when the action is triggered.
  onTapTwo(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.libraryloginScreen);
  }
}
