import 'package:ahmed_s_application6/widgets/custom_text_form_field.dart';
import 'package:ahmed_s_application6/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

// ignore_for_file: must_be_immutable
class LibraryregisterScreen extends StatefulWidget {
  LibraryregisterScreen({Key? key}) : super(key: key);

  @override
  State<LibraryregisterScreen> createState() => _LibraryregisterScreenState();
}

class _LibraryregisterScreenState extends State<LibraryregisterScreen> {
  TextEditingController lockController = TextEditingController();

  TextEditingController checkmarkController = TextEditingController();

  TextEditingController downloadTwoController = TextEditingController();

  TextEditingController downloadOneController = TextEditingController();

  TextEditingController eyeController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: Column(children: [
                      SizedBox(height: 68.v),
                      Expanded(
                          child: SingleChildScrollView(
                              child: Container(
                                  margin: EdgeInsets.only(bottom: 94.v),
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 11.h),
                                  child: Column(children: [
                                    GestureDetector(
                                      onTap: () {
                                        Navigator.pop(
                                          context,
                                        );
                                      },
                                      child: CustomImageView(
                                          imagePath:
                                              ImageConstant.imgArrowLeftRedA200,
                                          height: 27.v,
                                          width: 41.h,
                                          alignment: Alignment.centerRight,
                                          margin: EdgeInsets.only(right: 26.h)),
                                    ),
                                    SizedBox(height: 30.v),
                                    Align(
                                        alignment: Alignment.centerRight,
                                        child: Center(
                                          child: Text("تسجيل حساب",
                                              style: theme
                                                  .textTheme.headlineMedium),
                                        )),
                                    SizedBox(height: 21.v),
                                    _buildLock(context),
                                    SizedBox(height: 17.v),
                                    _buildCheckmark(context),
                                    SizedBox(height: 13.v),
                                    _buildDownloadTwo(context),
                                    SizedBox(height: 15.v),
                                    _buildDownloadOne(context),
                                    SizedBox(height: 15.v),
                                    _buildEye(context),
                                    SizedBox(height: 70.v),
                                    _buildTf(context)
                                  ]))))
                    ])))));
  }

  /// Section Widget
  Widget _buildLock(BuildContext context) {
    return CustomTextFormField(
        controller: lockController,
        hintText: "الأسم كامل",
        hintStyle: CustomTextStyles.titleMediumGray500,
        suffix: Container(
            margin: EdgeInsets.fromLTRB(8.h, 19.v, 17.h, 21.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgLock, height: 26.v, width: 25.h)),
        suffixConstraints: BoxConstraints(maxHeight: 68.v));
  }

  /// Section Widget
  Widget _buildCheckmark(BuildContext context) {
    return CustomTextFormField(
        controller: checkmarkController,
        hintText: "البريد الالكتروني",
        hintStyle: CustomTextStyles.titleMediumGray500,
        suffix: Container(
            margin: EdgeInsets.fromLTRB(8.h, 22.v, 15.h, 19.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgCheckmark,
                height: 26.v,
                width: 25.h)),
        suffixConstraints: BoxConstraints(maxHeight: 68.v),
        contentPadding: EdgeInsets.only(left: 30.h, top: 24.v, bottom: 24.v));
  }

  /// Section Widget
  Widget _buildDownloadTwo(BuildContext context) {
    return CustomTextFormField(
        controller: downloadTwoController,
        hintText: "أسم المكتبة",
        hintStyle: CustomTextStyles.titleMediumGray500,
        suffix: Container(
            margin: EdgeInsets.fromLTRB(8.h, 21.v, 16.h, 22.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgDownload225x25,
                height: 25.adaptSize,
                width: 25.adaptSize)),
        suffixConstraints: BoxConstraints(maxHeight: 68.v));
  }

  /// Section Widget
  Widget _buildDownloadOne(BuildContext context) {
    return CustomTextFormField(
        controller: downloadOneController,
        hintText: "رقم الهاتف",
        hintStyle: CustomTextStyles.titleMediumGray500,
        suffix: Container(
            margin: EdgeInsets.fromLTRB(6.h, 24.v, 16.h, 10.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgDownload133x37,
                height: 33.v,
                width: 37.h)),
        suffixConstraints: BoxConstraints(maxHeight: 68.v),
        contentPadding: EdgeInsets.only(left: 30.h, top: 24.v, bottom: 24.v));
  }

  /// Section Widget
  Widget _buildEye(BuildContext context) {
    return CustomTextFormField(
        controller: eyeController,
        hintText: "كلمة المرور",
        hintStyle: theme.textTheme.titleMedium!,
        textInputAction: TextInputAction.done,
        textInputType: TextInputType.visiblePassword,
        prefix: Container(
            margin: EdgeInsets.fromLTRB(15.h, 19.v, 30.h, 18.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgEye, height: 30.v, width: 27.h)),
        prefixConstraints: BoxConstraints(maxHeight: 68.v),
        suffix: Container(
            margin: EdgeInsets.fromLTRB(9.h, 22.v, 16.h, 14.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgLocation,
                height: 31.v,
                width: 32.h)),
        suffixConstraints: BoxConstraints(maxHeight: 68.v),
        obscureText: true,
        contentPadding: EdgeInsets.symmetric(vertical: 24.v));
  }

  /// Section Widget
  Widget _buildTf(BuildContext context) {
    return CustomElevatedButton(
        height: 71.v,
        text: "تسجيل الحساب".toUpperCase(),
        margin: EdgeInsets.only(left: 28.h, right: 32.h),
        buttonStyle: CustomButtonStyles.outlinePrimary,
        buttonTextStyle: CustomTextStyles.bodyLargeInterWhiteA700,
        onPressed: () {
          onTaptf(context);
        });
  }

  /// Navigates to the librarymainScreen when the action is triggered.
  onTaptf(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.librarymainScreen);
  }
}
