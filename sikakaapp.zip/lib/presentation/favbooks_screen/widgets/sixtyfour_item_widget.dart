import 'package:ahmed_s_application6/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

// ignore: must_be_immutable
class SixtyfourItemWidget extends StatelessWidget {
  SixtyfourItemWidget({
    Key? key,
    this.onTapWidget,
  }) : super(
          key: key,
        );

  VoidCallback? onTapWidget;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 174.v,
      width: 146.h,
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: GestureDetector(
              onTap: () {
                onTapWidget!.call();
              },
              child: Container(
                margin: EdgeInsets.only(right: 13.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 23.h,
                  vertical: 9.v,
                ),
                decoration: AppDecoration.fillOrange.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder21,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(height: 3.v),
                    CustomImageView(
                      imagePath: ImageConstant.imgDownload1,
                      height: 114.v,
                      width: 84.h,
                    ),
                    SizedBox(height: 3.v),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(right: 3.h),
                        child: Text(
                          "مقدمة ابن خلدون",
                          style: theme.textTheme.labelMedium,
                        ),
                      ),
                    ),
                    SizedBox(height: 3.v),
                    Align(
                      alignment: Alignment.center,
                      child: Text(
                        "التاريخ",
                        style: CustomTextStyles.poppinsGray800b7,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          CustomIconButton(
            height: 26.v,
            width: 28.h,
            padding: EdgeInsets.all(7.h),
            alignment: Alignment.topRight,
            child: CustomImageView(
              imagePath: ImageConstant.imgFavorite,
            ),
          ),
        ],
      ),
    );
  }
}
