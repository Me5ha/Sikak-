import 'package:ahmed_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_title_searchview.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_trailing_image_one.dart';
import 'widgets/sixtyfour_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

// ignore_for_file: must_be_immutable
class FavbooksScreen extends StatelessWidget {
  FavbooksScreen({Key? key}) : super(key: key);

  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(context),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 13.h, vertical: 35.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Padding(
                          padding: EdgeInsets.only(right: 9.h),
                          child: Text("مفضلاتي:",
                              style: CustomTextStyles.headlineSmallInter)),
                      SizedBox(height: 24.v),
                      _buildSixtyFour(context)
                    ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 59.h,
        leading: Container(
            margin: EdgeInsets.only(left: 7.h, top: 20.v, bottom: 14.v),
            padding: EdgeInsets.symmetric(horizontal: 17.h, vertical: 7.v),
            decoration: AppDecoration.fillRedA
                .copyWith(borderRadius: BorderRadiusStyle.circleBorder15),
            child: Column(children: [
              SizedBox(height: 1.v),
              AppbarImage(
                  imagePath: ImageConstant.imgCocoBoldSearch,
                  margin: EdgeInsets.only(right: 1.h))
            ])),
        title: AppbarTitleSearchview(
            margin: EdgeInsets.only(top: 20.v, right: 85.h, bottom: 14.v),
            hintText: "ابحث ..",
            controller: searchController),
        actions: [
          AppbarTrailingImageOne(
              imagePath: ImageConstant.imgImg9490264x99,
              margin: EdgeInsets.only(left: 217.h))
        ]);
  }

  /// Section Widget
  Widget _buildSixtyFour(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 21.h),
        child: GridView.builder(
            shrinkWrap: true,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                mainAxisExtent: 175.v,
                crossAxisCount: 3,
                mainAxisSpacing: 169.h,
                crossAxisSpacing: 169.h),
            physics: NeverScrollableScrollPhysics(),
            itemCount: 9,
            itemBuilder: (context, index) {
              return SixtyfourItemWidget(onTapWidget: () {
                onTapWidget(context);
              });
            }));
  }

  /// Navigates to the bookdetailsScreen when the action is triggered.
  onTapWidget(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookdetailsScreen);
  }
}
