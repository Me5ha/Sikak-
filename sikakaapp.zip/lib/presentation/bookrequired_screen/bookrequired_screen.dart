import 'package:ahmed_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_leading_image.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_subtitle.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_trailing_image.dart';
import 'widgets/view_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class BookrequiredScreen extends StatelessWidget {
  const BookrequiredScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildIMG(context),
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 49.h,
                  vertical: 36.v,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "الكتب المطلوبه:",
                      style: theme.textTheme.headlineSmall,
                    ),
                    SizedBox(height: 25.v),
                    _buildView(context),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildIMG(BuildContext context) {
    return SizedBox(
      height: 55.v,
      width: 371.h,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImg9490255x109,
            height: 55.v,
            width: 109.h,
            alignment: Alignment.centerLeft,
          ),
          CustomAppBar(
            height: 37.v,
            leadingWidth: 46.h,
            leading: AppbarLeadingImage(
              imagePath: ImageConstant.imgHamburgerMenu,
              margin: EdgeInsets.only(
                left: 13.h,
                top: 8.v,
              ),
            ),
            title: AppbarSubtitle(
              text: "ابحث ..",
              margin: EdgeInsets.only(left: 49.h),
            ),
            actions: [
              AppbarTrailingImage(
                imagePath: ImageConstant.imgArrowLeftTeal900,
                margin: EdgeInsets.fromLTRB(19.h, 5.v, 19.h, 13.v),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildView(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 1.h),
      child: GridView.builder(
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          mainAxisExtent: 193.v,
          crossAxisCount: 2,
          mainAxisSpacing: 39.h,
          crossAxisSpacing: 39.h,
        ),
        physics: NeverScrollableScrollPhysics(),
        itemCount: 7,
        itemBuilder: (context, index) {
          return ViewItemWidget();
        },
      ),
    );
  }
}
