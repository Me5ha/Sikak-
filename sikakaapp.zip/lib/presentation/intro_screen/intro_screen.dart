import 'package:ahmed_s_application6/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class IntroScreen extends StatelessWidget {
  const IntroScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            floatingActionButton: FloatingActionButton(
              onPressed: () {
                onTapBtnArrowLeft(context);
              },
              child: const Icon(Icons.arrow_forward_ios,
                  color: Colors.white, size: 28),
              backgroundColor: Color.fromARGB(255, 255, 68, 0),
            ),
            body: SizedBox(
                width: double.maxFinite,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  SizedBox(height: 3.v),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Column(children: [
                    Align(
                        alignment: Alignment.centerRight,
                        child: Padding(
                            padding: EdgeInsets.only(left: 88.h),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                      child: Padding(
                                          padding: EdgeInsets.only(top: 39.v),
                                          child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 44.h),
                                                    child: Text("أهلا أمجد",
                                                        style: CustomTextStyles
                                                            .headlineLargeCyan900)),
                                                SizedBox(height: 38.v),
                                                SizedBox(
                                                    width: 219.h,
                                                    child: Text(
                                                        "مرحبًا بك في سكك\n\n عزيزي القارئ!",
                                                        maxLines: 4,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: theme.textTheme
                                                            .headlineLarge))
                                              ]))),
                                  CustomImageView(
                                      imagePath: ImageConstant.imgPolygon17,
                                      height: 159.v,
                                      width: 75.h,
                                      radius: BorderRadius.circular(8.h),
                                      margin: EdgeInsets.only(
                                          left: 6.h, bottom: 50.v))
                                ]))),
                    SizedBox(height: 11.v),
                    SizedBox(
                        height: 624.v,
                        width: double.maxFinite,
                        child:
                            Stack(alignment: Alignment.bottomRight, children: [
                          _buildTwelve(context),
                          CustomImageView(
                              imagePath: ImageConstant.imgPolygon9,
                              height: 159.v,
                              width: 92.h,
                              radius: BorderRadius.circular(21.h),
                              alignment: Alignment.bottomRight,
                              margin: EdgeInsets.only(bottom: 208.v)),
                          Align(
                              alignment: Alignment.bottomLeft,
                              child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CustomImageView(
                                        imagePath: ImageConstant.imgEllipse8,
                                        height: 196.v,
                                        width: 106.h,
                                        margin: EdgeInsets.only(top: 24.v)),
                                    Padding(
                                        padding: EdgeInsets.only(
                                            left: 54.h, bottom: 30.v),
                                        child: Column(children: [
                                          // CustomIconButton(
                                          //     height: 69.v,
                                          //     width: 66.h,
                                          //     padding: EdgeInsets.all(25.h),
                                          //     onTap: () {
                                          //       onTapBtnArrowLeft(context);
                                          //     },
                                          //     child: CustomImageView(
                                          //         imagePath: ImageConstant
                                          //             .imgArrowLeft)),
                                          SizedBox(height: 87.v),
                                          CustomImageView(
                                              imagePath: ImageConstant.imgUser,
                                              height: 34.v,
                                              width: 37.h,
                                              radius:
                                                  BorderRadius.circular(3.h))
                                        ]))
                                  ])),
                          CustomImageView(
                              imagePath: ImageConstant.imgUserOrange200,
                              height: 44.v,
                              width: 30.h,
                              radius: BorderRadius.circular(3.h),
                              alignment: Alignment.centerLeft)
                        ]))
                  ])))
                ]))));
  }

  /// Section Widget
  Widget _buildTwelve(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: SizedBox(
            height: 292.v,
            width: double.maxFinite,
            child: Stack(alignment: Alignment.topLeft, children: [
              CustomImageView(
                  imagePath: ImageConstant.imgManWomanStudy,
                  height: 292.v,
                  width: 390.h,
                  alignment: Alignment.center),
              CustomImageView(
                  imagePath: ImageConstant.imgArrowRight,
                  height: 19.v,
                  width: 11.h,
                  alignment: Alignment.topLeft,
                  margin: EdgeInsets.only(left: 62.h, top: 124.v))
            ])));
  }

  /// Navigates to the mainuserScreen when the action is triggered.
  onTapBtnArrowLeft(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.mainuserScreen);
  }
}
