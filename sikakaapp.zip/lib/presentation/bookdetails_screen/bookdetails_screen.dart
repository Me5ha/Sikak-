import 'package:ahmed_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_trailing_iconbutton.dart';
import 'package:ahmed_s_application6/widgets/custom_icon_button.dart';
import 'package:ahmed_s_application6/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class BookdetailsScreen extends StatelessWidget {
  const BookdetailsScreen({Key? key}) : super(key: key);
//book_det.png
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/images/book_det.png"),
                fit: BoxFit.fill)),
      ),
    ));
  }

  /// Section Widget
  Widget _buildIMG(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(right: 15.h),
        child: Row(children: [
          CustomImageView(
              imagePath: ImageConstant.imgImg9490250x105,
              height: 50.v,
              width: 105.h),
          CustomAppBar(height: 49.v, actions: [
            AppbarTrailingIconbutton(
                margin: EdgeInsets.symmetric(horizontal: 16.h))
          ])
        ]));
  }

  /// Section Widget
  Widget _buildVectorThree(BuildContext context) {
    return SizedBox(
        height: 222.v,
        width: double.maxFinite,
        child: Stack(alignment: Alignment.center, children: [
          CustomImageView(
              imagePath: ImageConstant.imgVector3,
              height: 196.v,
              width: 390.h,
              alignment: Alignment.center),
          CustomImageView(
              imagePath: ImageConstant.imgDownload1222x159,
              height: 222.v,
              width: 159.h,
              alignment: Alignment.center),
          CustomImageView(
              imagePath: ImageConstant.imgSort,
              height: 44.v,
              width: 22.h,
              radius: BorderRadius.circular(3.h),
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(bottom: 61.v))
        ]));
  }

  /// Section Widget
  Widget _buildSort(BuildContext context) {
    return Align(
        alignment: Alignment.centerLeft,
        child: Padding(
            padding: EdgeInsets.only(right: 35.h),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              CustomImageView(
                  imagePath: ImageConstant.imgSort,
                  height: 44.v,
                  width: 22.h,
                  radius: BorderRadius.circular(3.h),
                  margin: EdgeInsets.only(top: 7.v, bottom: 93.v)),
              Expanded(
                  child: Padding(
                      padding: EdgeInsets.only(left: 13.h),
                      child: Column(children: [
                        Text("مقدمة ابن خلدون",
                            style: CustomTextStyles.headlineLargePoppins),
                        Text("تاريخي, علمي اجتماعي",
                            style: theme.textTheme.bodyLarge),
                        SizedBox(height: 11.v),
                        SizedBox(
                            width: 318.h,
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text("عدد مرات الاستعاره",
                                      style:
                                          CustomTextStyles.bodyLargeGray60001),
                                  Padding(
                                      padding: EdgeInsets.only(left: 27.h),
                                      child: Text("الكاتب",
                                          style: CustomTextStyles
                                              .bodyLargeGray60001)),
                                  Spacer(),
                                  Text("الصفحات",
                                      style: CustomTextStyles.bodyLargeGray600)
                                ])),
                        SizedBox(height: 7.v),
                        Align(
                            alignment: Alignment.centerRight,
                            child: Container(
                                width: 233.h,
                                margin:
                                    EdgeInsets.only(left: 66.h, right: 19.h),
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Padding(
                                          padding: EdgeInsets.only(top: 4.v),
                                          child: Text("2",
                                              style: CustomTextStyles
                                                  .titleMediumPoppinsErrorContainer)),
                                      Spacer(flex: 56),
                                      Padding(
                                          padding: EdgeInsets.symmetric(
                                              vertical: 2.v),
                                          child: Text("ابن خلدون",
                                              style: CustomTextStyles
                                                  .titleMediumPoppinsErrorContainer)),
                                      Spacer(flex: 43),
                                      Padding(
                                          padding: EdgeInsets.only(bottom: 4.v),
                                          child: Text("152",
                                              style: CustomTextStyles
                                                  .titleMediumPoppinsErrorContainer))
                                    ])))
                      ])))
            ])));
  }

  /// Section Widget
  Widget _buildThirtyFour(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 36.h, right: 23.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Padding(
              padding: EdgeInsets.only(top: 7.v),
              child: CustomIconButton(
                  height: 44.v,
                  width: 45.h,
                  padding: EdgeInsets.all(8.h),
                  decoration: IconButtonStyleHelper.fillRedA,
                  child: CustomImageView(
                      imagePath: ImageConstant.imgCocoBoldSaved))),
          CustomElevatedButton(
              width: 156.h,
              text: "استعارة الأن",
              onPressed: () {
                onTaptf(context);
              })
        ]));
  }

  /// Navigates to the booklistScreen when the action is triggered.
  onTaptf(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.booklistScreen);
  }
}
