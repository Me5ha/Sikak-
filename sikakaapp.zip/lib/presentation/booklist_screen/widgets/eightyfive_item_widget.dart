import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

// ignore: must_be_immutable
class EightyfiveItemWidget extends StatelessWidget {
  const EightyfiveItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: CustomImageView(
        imagePath: ImageConstant.imgDownload1,
        height: 109.v,
        width: 80.h,
      ),
    );
  }
}
