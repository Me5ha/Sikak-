import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

// ignore: must_be_immutable
class SeventythreeItemWidget extends StatelessWidget {
  const SeventythreeItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: CustomImageView(
        imagePath: ImageConstant.imgImages1,
        height: 115.v,
        width: 88.h,
      ),
    );
  }
}
