import 'package:ahmed_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_trailing_image.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_title.dart';
import 'widgets/eightyfive_item_widget.dart';
import 'widgets/seventythree_item_widget.dart';
import 'package:ahmed_s_application6/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class BooklistScreen extends StatelessWidget {
  const BooklistScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.gray20001,
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              SizedBox(height: 33.v),
              _buildFourteen(context),
              Container(
                padding: EdgeInsets.symmetric(vertical: 28.v),
                child: Column(
                  children: [
                    _buildThirteen(context),
                    SizedBox(height: 274.v),
                    CustomElevatedButton(
                      width: 156.h,
                      text: "استعارة الأن",
                    ),
                    SizedBox(height: 5.v),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildFourteen(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 3.v),
      decoration: AppDecoration.fillWhiteA,
      child: Column(
        children: [
          CustomAppBar(
            height: 24.v,
            actions: [
              AppbarTrailingImage(
                imagePath: ImageConstant.imgArrowDown,
                margin: EdgeInsets.only(
                  left: 17.h,
                  top: 7.v,
                  bottom: 10.v,
                ),
              ),
              AppbarTitle(
                text: "من نجود",
                margin: EdgeInsets.only(
                  left: 20.h,
                  right: 17.h,
                ),
              ),
            ],
          ),
          SizedBox(height: 13.v),
          SizedBox(
            height: 139.v,
            width: 339.h,
            child: Stack(
              alignment: Alignment.topCenter,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: ListView.separated(
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    separatorBuilder: (
                      context,
                      index,
                    ) {
                      return SizedBox(
                        height: 13.v,
                      );
                    },
                    itemCount: 2,
                    itemBuilder: (context, index) {
                      return EightyfiveItemWidget();
                    },
                  ),
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: 86.h,
                      top: 14.v,
                      right: 92.h,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                            "ابن خلدون",
                            style: theme.textTheme.titleLarge,
                          ),
                        ),
                        SizedBox(height: 1.v),
                        SizedBox(
                          height: 46.v,
                          width: 159.h,
                          child: Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              Align(
                                alignment: Alignment.topRight,
                                child: Text(
                                  "تاريخي, علمي اجتماعي",
                                  style: theme.textTheme.bodyLarge,
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Text(
                                  "المدة:من شهر الى شهرين",
                                  style: theme.textTheme.bodyLarge,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 6.v),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildThirteen(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.symmetric(horizontal: 9.h),
      decoration: AppDecoration.fillWhiteA,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Padding(
            padding: EdgeInsets.only(right: 3.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgArrowDown,
                  height: 7.v,
                  width: 11.h,
                  margin: EdgeInsets.only(
                    top: 9.v,
                    bottom: 6.v,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 12.h),
                  child: Text(
                    "من مكتبة أثراء",
                    style: CustomTextStyles.bodyLargeRedA200,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 12.v),
          SizedBox(
            height: 140.v,
            width: 347.h,
            child: Stack(
              alignment: Alignment.topCenter,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: ListView.separated(
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    separatorBuilder: (
                      context,
                      index,
                    ) {
                      return SizedBox(
                        height: 8.v,
                      );
                    },
                    itemCount: 2,
                    itemBuilder: (context, index) {
                      return SeventythreeItemWidget();
                    },
                  ),
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: 92.h,
                      top: 17.v,
                      right: 101.h,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                            "بداية ونهاية",
                            style: theme.textTheme.titleLarge,
                          ),
                        ),
                        SizedBox(
                          height: 45.v,
                          width: 152.h,
                          child: Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              Align(
                                alignment: Alignment.topRight,
                                child: Text(
                                  "الأدب العربي",
                                  style: theme.textTheme.bodyLarge,
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Text(
                                  "المدة:من أسبوعين لشهر",
                                  style: theme.textTheme.bodyLarge,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 12.v),
        ],
      ),
    );
  }
}
