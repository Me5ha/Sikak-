import 'package:ahmed_s_application6/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class UserregisterScreen extends StatelessWidget {
  UserregisterScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController lockController = TextEditingController();

  TextEditingController checkmarkController = TextEditingController();

  TextEditingController downloadOneController = TextEditingController();

  TextEditingController eyeController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 10.h),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(
                          context,
                        );
                      },
                      child: CustomImageView(
                        imagePath: ImageConstant.imgArrowLeftRedA200,
                        height: 27.v,
                        width: 41.h,
                        alignment: Alignment.centerRight,
                        margin: EdgeInsets.only(right: 28.h),
                      ),
                    ),
                    SizedBox(height: 31.v),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(right: 18.h),
                        child: Center(
                          child: Text(
                            "تسجيل حساب",
                            style: CustomTextStyles.headlineMediumRegular,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 27.v),
                    _buildLock(context),
                    SizedBox(height: 44.v),
                    _buildCheckmark(context),
                    SizedBox(height: 36.v),
                    _buildDownloadOne(context),
                    SizedBox(height: 36.v),
                    _buildEye(context),
                    SizedBox(height: 72.v),
                    SizedBox(
                      height: 71.v,
                      width: 306.h,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Card(
                              clipBehavior: Clip.antiAlias,
                              elevation: 0,
                              margin: EdgeInsets.all(0),
                              color: appTheme.redA200,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadiusStyle.circleBorder15,
                              ),
                              child: Container(
                                height: 71.v,
                                width: 306.h,
                                padding: EdgeInsets.symmetric(
                                  horizontal: 15.h,
                                  vertical: 17.v,
                                ),
                                decoration:
                                    AppDecoration.outlinePrimary.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.circleBorder15,
                                ),
                                child: Stack(
                                  alignment: Alignment.topRight,
                                  children: [
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: Container(
                                        height: 36.v,
                                        width: 33.h,
                                        decoration: BoxDecoration(
                                          color: appTheme.red90002,
                                          borderRadius: BorderRadius.circular(
                                            18.h,
                                          ),
                                        ),
                                      ),
                                    ),
                                    CustomImageView(
                                      imagePath:
                                          ImageConstant.imgArrowLeftWhiteA700,
                                      height: 15.v,
                                      width: 14.h,
                                      alignment: Alignment.topRight,
                                      margin: EdgeInsets.only(
                                        top: 9.v,
                                        right: 10.h,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.center,
                            child: Text(
                              "تسجيل الحساب".toUpperCase(),
                              style:
                                  CustomTextStyles.bodyLargeInterErrorContainer,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 5.v),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildLock(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 8.h),
      child: CustomTextFormField(
        controller: lockController,
        hintText: "الأسم كامل",
        hintStyle: CustomTextStyles.titleMediumGray500,
        suffix: Container(
          margin: EdgeInsets.fromLTRB(8.h, 19.v, 17.h, 21.v),
          child: CustomImageView(
            imagePath: ImageConstant.imgLock,
            height: 26.v,
            width: 25.h,
          ),
        ),
        suffixConstraints: BoxConstraints(
          maxHeight: 68.v,
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildCheckmark(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 8.h),
      child: CustomTextFormField(
        controller: checkmarkController,
        hintText: "البريد الالكتروني",
        hintStyle: CustomTextStyles.titleMediumGray500,
        suffix: Container(
          margin: EdgeInsets.fromLTRB(8.h, 24.v, 15.h, 17.v),
          child: CustomImageView(
            imagePath: ImageConstant.imgCheckmark,
            height: 26.v,
            width: 25.h,
          ),
        ),
        suffixConstraints: BoxConstraints(
          maxHeight: 68.v,
        ),
        contentPadding: EdgeInsets.only(
          left: 30.h,
          top: 24.v,
          bottom: 24.v,
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildDownloadOne(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 8.h),
      child: CustomTextFormField(
        controller: downloadOneController,
        hintStyle: CustomTextStyles.titleMediumGray500,
        hintText: "رقم الهاتف",
        suffix: Container(
          margin: EdgeInsets.fromLTRB(6.h, 17.v, 10.h, 16.v),
          child: CustomImageView(
            imagePath: ImageConstant.imgDownload133x37,
            height: 33.v,
            width: 37.h,
          ),
        ),
        suffixConstraints: BoxConstraints(
          maxHeight: 67.v,
        ),
        contentPadding: EdgeInsets.only(
          left: 30.h,
          top: 23.v,
          bottom: 23.v,
        ),
        borderDecoration: TextFormFieldStyleHelper.outlineGrayTL12,
      ),
    );
  }

  /// Section Widget
  Widget _buildEye(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 7.h),
      child: CustomTextFormField(
        controller: eyeController,
        hintText: "كلمة المرور",
        hintStyle: theme.textTheme.titleMedium!,
        textInputAction: TextInputAction.done,
        textInputType: TextInputType.visiblePassword,
        prefix: Container(
          margin: EdgeInsets.fromLTRB(14.h, 20.v, 30.h, 20.v),
          child: CustomImageView(
            imagePath: ImageConstant.imgEye,
            height: 30.v,
            width: 27.h,
          ),
        ),
        prefixConstraints: BoxConstraints(
          maxHeight: 71.v,
        ),
        suffix: Container(
          margin: EdgeInsets.fromLTRB(9.h, 19.v, 12.h, 19.v),
          child: CustomImageView(
            imagePath: ImageConstant.imgLocation,
            height: 31.v,
            width: 32.h,
          ),
        ),
        suffixConstraints: BoxConstraints(
          maxHeight: 71.v,
        ),
        obscureText: true,
        contentPadding: EdgeInsets.symmetric(vertical: 25.v),
        borderDecoration: TextFormFieldStyleHelper.outlineGrayTL121,
      ),
    );
  }
}
