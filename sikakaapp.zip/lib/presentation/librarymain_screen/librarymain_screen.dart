import 'package:ahmed_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_title_searchview_one.dart';
import 'package:ahmed_s_application6/widgets/custom_elevated_button.dart';
import 'package:ahmed_s_application6/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

// ignore_for_file: must_be_immutable
class LibrarymainScreen extends StatelessWidget {
  LibrarymainScreen({Key? key}) : super(key: key);

  TextEditingController searchController = TextEditingController();

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SingleChildScrollView(
              child: Container(
                  width: double.maxFinite,
                  padding: EdgeInsets.symmetric(vertical: 8.v),
                  child: Column(children: [
                    // _buildIMG(context),
                    SearchInput(),

                    Container(
                        padding: EdgeInsets.symmetric(horizontal: 12.h),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              SizedBox(height: 26.v),
                              Padding(
                                  padding: EdgeInsets.only(right: 4.h),
                                  child: Text("الكتب المتاحه للتبادل",
                                      style: theme.textTheme.headlineSmall)),
                              SizedBox(height: 21.v),
                              _buildNine(context),
                              SizedBox(height: 52.v),
                              Padding(
                                  padding: EdgeInsets.only(right: 16.h),
                                  child: Text("الكتب المطلوبة",
                                      style: theme.textTheme.headlineSmall)),
                              SizedBox(height: 13.v),
                              _buildEight(context),
                              SizedBox(height: 20.v),
                              Padding(
                                  padding: EdgeInsets.only(right: 19.h),
                                  child: Text("شراكات المكتبات",
                                      style: theme.textTheme.headlineSmall)),
                              SizedBox(height: 93.v),
                              CustomElevatedButton(
                                  height: 31.v,
                                  width: 123.h,
                                  text: "الاتصال مع المكتبات",
                                  buttonStyle: CustomButtonStyles.fillBlueGray,
                                  buttonTextStyle:
                                      CustomTextStyles.labelMediumWhiteA700,
                                  alignment: Alignment.center)
                            ]))
                  ])),
            ),
            bottomNavigationBar: Padding(
                padding: EdgeInsets.symmetric(horizontal: 12.h),
                child: _buildBottomBar(context))));
  }

  /// Section Widget
  Widget _buildIMG(BuildContext context) {
    return Align(
        alignment: Alignment.centerRight,
        child: SizedBox(
            height: 74.v,
            width: 329.h,
            child: Stack(alignment: Alignment.bottomLeft, children: [
              CustomImageView(
                  imagePath: ImageConstant.imgImg9490274x111,
                  height: 74.v,
                  width: 111.h,
                  alignment: Alignment.centerRight),
              CustomAppBar(
                  height: 43.v,
                  title: AppbarTitleSearchviewOne(
                      margin: EdgeInsets.only(left: 61.h),
                      hintText: "ابحث ..",
                      controller: searchController))
            ])));
  }

  /// Section Widget
  Widget _buildNine(BuildContext context) {
    return GestureDetector(
        onTap: () {
          onTapNine(context);
        },
        child: Container(
            padding: EdgeInsets.symmetric(vertical: 21.v),
            decoration: AppDecoration.fillTeal
                .copyWith(borderRadius: BorderRadiusStyle.circleBorder15),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  CustomImageView(
                      imagePath: ImageConstant.imgDownload9131x85,
                      height: 131.v,
                      width: 85.h,
                      margin: EdgeInsets.only(top: 14.v)),
                  CustomImageView(
                      imagePath: ImageConstant.imgShopping1,
                      height: 131.v,
                      width: 87.h,
                      margin: EdgeInsets.only(top: 14.v)),
                  CustomImageView(
                      imagePath: ImageConstant.imgDownload5,
                      height: 129.v,
                      width: 98.h,
                      margin: EdgeInsets.only(top: 14.v, right: 19.h))
                ])));
  }

  /// Section Widget
  Widget _buildEight(BuildContext context) {
    return GestureDetector(
        onTap: () {
          onTapEight(context);
        },
        child: Container(
            padding: EdgeInsets.symmetric(vertical: 26.v),
            decoration: AppDecoration.fillTeal
                .copyWith(borderRadius: BorderRadiusStyle.circleBorder15),
            child: Row(children: [
              CustomImageView(
                  imagePath: ImageConstant.imgDownload7,
                  height: 131.v,
                  width: 85.h,
                  margin: EdgeInsets.only(top: 2.v)),
              CustomImageView(
                  imagePath: ImageConstant.imgShopping3131x97,
                  height: 131.v,
                  width: 97.h,
                  margin: EdgeInsets.only(left: 29.h, top: 2.v)),
              CustomImageView(
                  imagePath: ImageConstant.imgDownload6,
                  height: 131.v,
                  width: 96.h,
                  margin: EdgeInsets.only(left: 29.h, top: 2.v))
            ])));
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {});
  }

  /// Navigates to the booksavailableScreen when the action is triggered.
  onTapNine(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.booksavailableScreen);
  }

  /// Navigates to the bookrequiredScreen when the action is triggered.
  onTapEight(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookrequiredScreen);
  }
}

class SearchInput extends StatelessWidget {
  static int purple01 = 0xff918fa5;
  static int purple02 = 0xff6b6e97;
  static int yellow01 = 0xffeaa63b;
  static int yellow02 = 0xfff29b2b;
  static int bg = 0xfff5f3fe;
  const SearchInput({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 230, 230, 230),
          borderRadius: BorderRadius.circular(5),
        ),
        padding: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 3),
              child: Icon(
                Icons.search,
                color: Color(purple02),
              ),
            ),
            const SizedBox(
              width: 15,
            ),
            Expanded(
              child: TextField(
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: 'ابحث عن اي شئ',
                  hintStyle: TextStyle(
                      fontSize: 13,
                      color: Color(purple01),
                      fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
