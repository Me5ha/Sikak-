import 'dart:developer';

import 'package:ahmed_s_application6/models/place_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_map_location_marker/flutter_map_location_marker.dart';
import 'package:latlong2/latlong.dart';

import '../../routes/app_routes.dart';

class HomeLibrary extends StatefulWidget {
  const HomeLibrary({Key? key}) : super(key: key);

  @override
  _HomeLibraryState createState() => _HomeLibraryState();
}

class _HomeLibraryState extends State<HomeLibrary> {
  List<PlaceModel> tappedPoints = [
    PlaceModel(
        logo: 'assets/images/lib1.jpeg',
        name: "name",
        latLng: LatLng(18.197053, 42.819017)),
    PlaceModel(
        logo: 'assets/images/lib2.jpeg',
        name: "name",
        latLng: LatLng(18.189354, 42.824600)),
    PlaceModel(
        logo: 'assets/images/lib3.jpg',
        name: "name",
        latLng: LatLng(18.192605, 42.836307)),
    PlaceModel(
        logo: 'assets/images/lib4.jpg',
        name: "name",
        latLng: LatLng(18.184734, 42.810912)),
    PlaceModel(
        logo: 'assets/images/lib5.jpeg',
        name: "name",
        latLng: LatLng(18.184477, 42.844232)),
  ];

  @override
  Widget build(BuildContext context) {
    final markers = tappedPoints.map((placeModel) {
      return Marker(
        width: 100,
        height: 100,
        point: placeModel.latLng,
        builder: (ctx) => GestureDetector(
          onTap: () {
            log("message");
          },
          child: Container(
            width: 180,
            padding: const EdgeInsets.all(10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Column(
                  children: [
                    Center(
                        child: GestureDetector(
                      onTap: () {
                        log("message");
                        // Navigator.pushNamed(context, AppRoutes.librarymainScreen);
                      },
                      child: CircleAvatar(
                        backgroundColor: Colors.yellow,
                        backgroundImage: AssetImage(placeModel.logo),
                      ),
                    )),
                    const Icon(
                      Icons.location_pin,
                      color: Colors.red,
                      size: 32,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    }).toList();

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                margin: const EdgeInsets.only(left: 18, top: 8, right: 18),
                height: 48,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 235, 235, 235),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: TextField(
                  textAlign: TextAlign.start,
                  autocorrect: false,
                  autofocus: true,
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.black,
                  ),
                  decoration: InputDecoration(
                    icon: Container(
                      margin: EdgeInsets.only(left: 12),
                      width: 32,
                      child: Icon(
                        Icons.search_rounded,
                        color: Colors.black,
                        size: 32,
                      ),
                    ),
                    hintText: "بحث... ",
                    border: InputBorder.none,
                  ),
                ),
              ),
              SizedBox(height: 8),
              SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      height: 800,
                      child: FlutterMap(
                        options: MapOptions(
                            onTap: (tapPosition, point) {
                              Navigator.pushNamed(
                                  context, AppRoutes.librarymainScreen);
                            },
                            zoom: 13,
                            center: LatLng(18.189354, 42.824600)),
                        children: [
                          TileLayer(
                            urlTemplate:
                                'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                            userAgentPackageName:
                                'dev.fleaflet.flutter_map.example',
                          ),
                          MarkerLayer(markers: markers),
                          CurrentLocationLayer()
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
