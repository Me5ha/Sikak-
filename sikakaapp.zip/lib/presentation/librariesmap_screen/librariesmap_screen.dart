import 'package:ahmed_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_trailing_image.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class LibrariesmapScreen extends StatelessWidget {
  const LibrariesmapScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              _buildIMG(context),
              Container(
                padding: EdgeInsets.symmetric(vertical: 59.v),
                child: Column(
                  children: [
                    SizedBox(
                      width: 205.h,
                      child: Text(
                        "المكاتب المشاركة في المملكة",
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style:
                            CustomTextStyles.titleMediumRalewayTeal900.copyWith(
                          height: 1.29,
                        ),
                      ),
                    ),
                    SizedBox(height: 20.v),
                    SizedBox(
                      height: 475.v,
                      width: double.maxFinite,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Container(
                              height: 461.v,
                              width: double.maxFinite,
                              decoration: BoxDecoration(
                                color: appTheme.teal900,
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.center,
                            child: SizedBox(
                              height: 475.v,
                              width: double.maxFinite,
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  CustomImageView(
                                    imagePath: ImageConstant.imgMaskGroup,
                                    height: 475.v,
                                    width: 390.h,
                                    alignment: Alignment.center,
                                  ),
                                  Align(
                                    alignment: Alignment.center,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                        left: 49.h,
                                        right: 39.h,
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgDownload23,
                                            height: 15.adaptSize,
                                            width: 15.adaptSize,
                                            margin: EdgeInsets.only(left: 75.h),
                                          ),
                                          SizedBox(height: 14.v),
                                          Row(
                                            children: [
                                              CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgDownload23,
                                                height: 15.adaptSize,
                                                width: 15.adaptSize,
                                              ),
                                              CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgDownload23,
                                                height: 15.adaptSize,
                                                width: 15.adaptSize,
                                                margin:
                                                    EdgeInsets.only(left: 33.h),
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 3.v),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgDownload23,
                                            height: 15.adaptSize,
                                            width: 15.adaptSize,
                                            margin:
                                                EdgeInsets.only(left: 120.h),
                                          ),
                                          SizedBox(height: 52.v),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgDownload23,
                                            height: 15.adaptSize,
                                            width: 15.adaptSize,
                                            margin: EdgeInsets.only(left: 48.h),
                                          ),
                                          SizedBox(height: 16.v),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgDownload23,
                                            height: 15.adaptSize,
                                            width: 15.adaptSize,
                                            margin: EdgeInsets.only(left: 82.h),
                                          ),
                                          SizedBox(height: 6.v),
                                          Padding(
                                            padding: EdgeInsets.only(
                                              left: 63.h,
                                              right: 91.h,
                                            ),
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                CustomImageView(
                                                  imagePath: ImageConstant
                                                      .imgDownload23,
                                                  height: 15.adaptSize,
                                                  width: 15.adaptSize,
                                                  margin:
                                                      EdgeInsets.only(top: 8.v),
                                                ),
                                                Spacer(),
                                                CustomImageView(
                                                  imagePath: ImageConstant
                                                      .imgDownload23,
                                                  height: 15.adaptSize,
                                                  width: 15.adaptSize,
                                                  margin: EdgeInsets.only(
                                                      bottom: 8.v),
                                                ),
                                                CustomImageView(
                                                  imagePath: ImageConstant
                                                      .imgDownload27,
                                                  height: 15.adaptSize,
                                                  width: 15.adaptSize,
                                                  margin: EdgeInsets.only(
                                                    left: 25.h,
                                                    bottom: 8.v,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(height: 8.v),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgDownload23,
                                            height: 15.adaptSize,
                                            width: 15.adaptSize,
                                            alignment: Alignment.centerRight,
                                          ),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgDownload23,
                                            height: 15.adaptSize,
                                            width: 15.adaptSize,
                                            margin: EdgeInsets.only(left: 78.h),
                                          ),
                                          SizedBox(height: 9.v),
                                          Align(
                                            alignment: Alignment.centerRight,
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                left: 93.h,
                                                right: 23.h,
                                              ),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgDownload23,
                                                    height: 15.adaptSize,
                                                    width: 15.adaptSize,
                                                    margin: EdgeInsets.only(
                                                      top: 28.v,
                                                      bottom: 12.v,
                                                    ),
                                                  ),
                                                  CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgDownload23,
                                                    height: 15.adaptSize,
                                                    width: 15.adaptSize,
                                                    margin: EdgeInsets.only(
                                                      left: 3.h,
                                                      top: 40.v,
                                                    ),
                                                  ),
                                                  CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgDownload23,
                                                    height: 15.adaptSize,
                                                    width: 15.adaptSize,
                                                    margin: EdgeInsets.only(
                                                      left: 30.h,
                                                      top: 20.v,
                                                      bottom: 20.v,
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgDownload23,
                                                    height: 15.adaptSize,
                                                    width: 15.adaptSize,
                                                    margin: EdgeInsets.only(
                                                        bottom: 40.v),
                                                  ),
                                                  CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgDownload23,
                                                    height: 15.adaptSize,
                                                    width: 15.adaptSize,
                                                    margin: EdgeInsets.only(
                                                      left: 14.h,
                                                      top: 12.v,
                                                      bottom: 28.v,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 5.v),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildIMG(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 6.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImg9490242x100,
            height: 42.v,
            width: 100.h,
          ),
          CustomAppBar(
            height: 42.v,
            actions: [
              AppbarTrailingImage(
                imagePath: ImageConstant.imgShape,
                margin: EdgeInsets.symmetric(horizontal: 7.h),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
