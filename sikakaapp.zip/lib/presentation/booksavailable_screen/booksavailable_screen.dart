import 'package:ahmed_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_leading_image.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_subtitle.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_trailing_image.dart';
import 'widgets/eightythree_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class BooksavailableScreen extends StatelessWidget {
  const BooksavailableScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildIMG(context),
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 49.h,
                  vertical: 24.v,
                ),
                child: Column(
                  children: [
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(right: 24.h),
                        child: Text(
                          "الكتب المتاحه للتبادل:",
                          style: theme.textTheme.headlineSmall,
                        ),
                      ),
                    ),
                    SizedBox(height: 33.v),
                    _buildEightyThree(context),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildIMG(BuildContext context) {
    return SizedBox(
      height: 60.v,
      width: 376.h,
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImg9490260x114,
            height: 60.v,
            width: 114.h,
            alignment: Alignment.centerLeft,
          ),
          CustomAppBar(
            height: 47.v,
            leadingWidth: 46.h,
            leading: AppbarLeadingImage(
              imagePath: ImageConstant.imgHamburgerMenu,
              margin: EdgeInsets.only(
                left: 13.h,
                top: 7.v,
              ),
            ),
            title: AppbarSubtitle(
              text: "ابحث ..",
              margin: EdgeInsets.only(left: 64.h),
            ),
            actions: [
              AppbarTrailingImage(
                imagePath: ImageConstant.imgArrowLeftTeal900,
                margin: EdgeInsets.fromLTRB(14.h, 7.v, 14.h, 10.v),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildEightyThree(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 1.h),
      child: GridView.builder(
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          mainAxisExtent: 192.v,
          crossAxisCount: 2,
          mainAxisSpacing: 39.h,
          crossAxisSpacing: 39.h,
        ),
        physics: NeverScrollableScrollPhysics(),
        itemCount: 6,
        itemBuilder: (context, index) {
          return EightythreeItemWidget();
        },
      ),
    );
  }
}
