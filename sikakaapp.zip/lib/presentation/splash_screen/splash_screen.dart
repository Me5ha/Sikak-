import 'dart:async';

import 'package:ahmed_s_application6/presentation/chooseaccount_screen/chooseaccount_screen.dart';
import 'package:ahmed_s_application6/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class SplashScreen extends StatefulWidget {
  SplashScreen({Key? key})
      : super(
          key: key,
        );

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    startTime();
  }

  startTime() async {
    var duration = Duration(seconds: 10);
    return new Timer(duration, route);
  }

  route() {
    Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (context) => ChooseaccountScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.teal900,
        resizeToAvoidBottomInset: false,
        body: Container(
          height: SizeUtils.height,
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(vertical: 214.v),
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgImg94891,
                height: 237.v,
                width: 390.h,
                alignment: Alignment.topCenter,
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  "منصة رقمية لتسهيل تبادل الكتب بين المكتبات في المملكة العربية السعودية",
                  style:
                      TextStyle(backgroundColor: appTheme.redA200, height: 2),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
