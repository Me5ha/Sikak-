import 'package:ahmed_s_application6/widgets/app_bar/custom_app_bar.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_image.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_title_searchview.dart';
import 'package:ahmed_s_application6/widgets/app_bar/appbar_trailing_image_one.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class LogoutScreen extends StatelessWidget {
  LogoutScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 12.h,
            vertical: 42.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildFortyEight(context),
              SizedBox(height: 16.v),
              Divider(
                indent: 5.h,
              ),
              SizedBox(height: 44.v),
              _buildThirtyNine(context),
              SizedBox(height: 18.v),
              Divider(
                indent: 6.h,
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 60.h,
      leading: Container(
        margin: EdgeInsets.only(
          left: 8.h,
          top: 20.v,
          bottom: 14.v,
        ),
        padding: EdgeInsets.symmetric(
          horizontal: 17.h,
          vertical: 7.v,
        ),
        decoration: AppDecoration.fillRedA.copyWith(
          borderRadius: BorderRadiusStyle.circleBorder15,
        ),
        child: Column(
          children: [
            SizedBox(height: 1.v),
            AppbarImage(
              imagePath: ImageConstant.imgCocoBoldSearch,
              margin: EdgeInsets.only(right: 1.h),
            ),
          ],
        ),
      ),
      title: AppbarTitleSearchview(
        margin: EdgeInsets.only(
          top: 20.v,
          right: 84.h,
          bottom: 14.v,
        ),
        hintText: "ابحث ..",
        controller: searchController,
      ),
      actions: [
        AppbarTrailingImageOne(
          imagePath: ImageConstant.imgImg9490264x98,
          margin: EdgeInsets.only(left: 217.h),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildFortyEight(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 7.h,
        right: 22.h,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgVector,
            height: 13.v,
            width: 6.h,
            margin: EdgeInsets.only(bottom: 11.v),
          ),
          Spacer(),
          Text(
            "الحساب",
            style: CustomTextStyles.bodyMediumPoppinsErrorContainer,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgIconPerson,
            height: 16.adaptSize,
            width: 16.adaptSize,
            margin: EdgeInsets.only(
              left: 19.h,
              bottom: 7.v,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildThirtyNine(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 9.h,
        right: 21.h,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgVector,
            height: 13.v,
            width: 6.h,
            margin: EdgeInsets.only(bottom: 9.v),
          ),
          Spacer(),
          Text(
            "تسجيل الخروج",
            style: CustomTextStyles.bodyMediumPoppinsErrorContainer,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgGroup,
            height: 10.v,
            width: 14.h,
            margin: EdgeInsets.only(
              left: 8.h,
              top: 3.v,
              bottom: 8.v,
            ),
          ),
        ],
      ),
    );
  }
}
