import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class AppNavigationScreen extends StatelessWidget {
  const AppNavigationScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFFFFFFFF),
        body: SizedBox(
          width: 375.h,
          child: Column(
            children: [
              _buildAppNavigation(context),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0XFFFFFFFF),
                    ),
                    child: Column(
                      children: [
                        _buildScreenTitle(
                          context,
                          screenTitle: "info",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.infoScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "logout",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.logoutScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "booklist",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.booklistScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "bookdetails",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.bookdetailsScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "favbooks",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.favbooksScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "mainuser",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.mainuserScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "intro",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.introScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "userregister",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.userregisterScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "login",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.loginScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "chooseaccount",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.chooseaccountScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "splash",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.splashScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "librariesmap",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.librariesmapScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "bookrequired",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.bookrequiredScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "booksavailable",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.booksavailableScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "librarymain",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.librarymainScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "libraryregister",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.libraryregisterScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "librarylogin",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.libraryloginScreen),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAppNavigation(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0XFFFFFFFF),
      ),
      child: Column(
        children: [
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.h),
              child: Text(
                "App Navigation",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF000000),
                  fontSize: 20.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 20.h),
              child: Text(
                "Check your app's UI from the below demo screens of your app.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF888888),
                  fontSize: 16.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 5.v),
          Divider(
            height: 1.v,
            thickness: 1.v,
            color: Color(0XFF000000),
          ),
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildScreenTitle(
    BuildContext context, {
    required String screenTitle,
    Function? onTapScreenTitle,
  }) {
    return GestureDetector(
      onTap: () {
        onTapScreenTitle!.call();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Color(0XFFFFFFFF),
        ),
        child: Column(
          children: [
            SizedBox(height: 10.v),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.h),
                child: Text(
                  screenTitle,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0XFF000000),
                    fontSize: 20.fSize,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10.v),
            SizedBox(height: 5.v),
            Divider(
              height: 1.v,
              thickness: 1.v,
              color: Color(0XFF888888),
            ),
          ],
        ),
      ),
    );
  }

  /// Common click event
  void onTapScreenTitle(
    BuildContext context,
    String routeName,
  ) {
    Navigator.pushNamed(context, routeName);
  }
}
