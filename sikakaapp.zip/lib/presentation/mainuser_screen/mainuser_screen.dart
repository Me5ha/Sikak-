import 'package:ahmed_s_application6/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:ahmed_s_application6/core/app_export.dart';

class MainuserScreen extends StatelessWidget {
  MainuserScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: GestureDetector(
        onTap: () {
          Navigator.pushNamed(context, AppRoutes.bookdetailsScreen);
        },
        child: Container(
          height: double.infinity,
          width: double.infinity,
          decoration: const BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("assets/images/m_user.png"),
                  fit: BoxFit.fill)),
        ),
      ),
    ));
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {},
    );
  }
}
