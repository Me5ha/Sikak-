import 'package:latlong2/latlong.dart';

class PlaceModel {
  final String name;
  final LatLng latLng;

  final String logo;

  const PlaceModel({
    required this.logo,
    required this.name,
    required this.latLng,
  });
}
